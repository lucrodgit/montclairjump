﻿# MontclairJump

Controls:
- 's' to crouch
- 'space' to jump
- 
Features:
- Jumping and falling gravity
- Obstacle class with movement
- Random obstacle sizes
- Getting hit = game over
- Score and Highscore
- Speedup after time
- Start and end screen
